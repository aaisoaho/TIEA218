import sys
sys.platform = 'linux3'