# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

# -------------------------------------------------------------------------
# This is a sample controller
# - index is the default action of any application
# - user is required for authentication and authorization
# - download is for downloading files uploaded in the db (does streaming)
# -------------------------------------------------------------------------


def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simply replace the two lines below with:
    return auth.wiki()
    """
    response.flash = T("Hello World")
    redirect(URL('vuokraamo'))


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()

@auth.requires_login()
def vuokraamo():
    response.flash = "Listaus vuokrauksista"
    vuokraajat = db().select(db.jasen.ALL, orderby=db.jasen.Nimi)
    elokuvat = db().select(db.elokuva.ALL)
    vuokraukset = db().select(db.vuokraus.ALL, orderby=db.vuokraus.VuokrausPVM)
    return dict(vuokraukset=vuokraukset,vuokraajat=vuokraajat,elokuvat=elokuvat)

@auth.requires_login()
def vuokraa():
	response.flash = "Vuokraa elokuva"
	form = SQLFORM(db.vuokraus, showid=False)
	if form.process().accepted:
		response.flash = 'Vuokraus on lisätty'
	elif form.errors:
		response.flash = 'Lomakkeen tiedoissa on virheitä'
	else:
		response.flash = 'Täytä lomake lisätäksesi vuokrauksen'
	return dict(lomake=form)

@auth.requires_login()
def vuokraaja():
	response.flash = "Lisää vuokraaja"
	form = SQLFORM(db.jasen, showid=False)
	if form.process().accepted:
		response.flash = 'Vuokraus on lisätty'
	elif form.errors:
		response.flash = 'Lomakkeen tiedoissa on virheitä'
	else:
		response.flash = 'Täytä lomake lisätäksesi vuokrauksen'
	return dict(lomake=form)

@auth.requires_login()
def elokuva():
	response.flash = "Lisää elokuva"
	form = SQLFORM(db.elokuva, showid=False)
	if form.process().accepted:
		response.flash = 'Vuokraus on lisätty'
	elif form.errors:
		response.flash = 'Lomakkeen tiedoissa on virheitä'
	else:
		response.flash = 'Täytä lomake lisätäksesi vuokrauksen'
	return dict(lomake=form)

@auth.requires_login()
def elokuvalista():
	from collections import OrderedDict
	response.flash = "Elokuvalistaus"
	elokuvat = db().select(db.elokuva.id,db.elokuva.Nimi)
	d = []
	for e in elokuvat:
		d.append({"id":e.id,"nimi":e.Nimi, "count": db(db.vuokraus.elokuva==e.id).count()})
	return dict(elokuvat=reversed(sorted(d,key=lambda t: t["count"])))
	
@auth.requires_login()
def muokkaa_elokuvaa():
	eid = request.get_vars['eid']
	if eid=="":
		redirect(URL('vuokraamo'))
	voiTuhota = (db.vuokraus(db.vuokraus.elokuva == eid)==None)
	lomake = SQLFORM(db.elokuva,eid,deletable=voiTuhota,showid=False)
	if lomake.process().accepted:
		response.flash = 'Lomake lähetetty'
	if lomake.errors:
		response.flash = 'Lomakkeessa oli virheitä.'
	return dict(lomake=lomake)
	
@auth.requires_login()
def muokkaa_kayttajaa():
	jid = request.get_vars['jid']
	if jid=="":
		redirect(URL('vuokraamo'))
	voiTuhota = (db.vuokraus(db.vuokraus.vuokraaja == jid)==None)
	lomake = SQLFORM(db.jasen,jid,deletable=voiTuhota,showid=False)
	if lomake.process().accepted:
		response.flash = 'Lomake lähetetty'
	if lomake.errors:
		response.flash = 'Lomakkeessa oli virheitä.'
	db.vuokraus.id.readable=False
	grid = SQLFORM.grid(db.vuokraus.vuokraaja==jid,csv=False)
	return dict(lomake=lomake,grid=grid)