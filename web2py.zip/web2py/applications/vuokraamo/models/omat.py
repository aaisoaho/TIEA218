from gluon.contrib.login_methods.gae_google_account import GaeGoogleAccount
auth.settings.login_form = GaeGoogleAccount()

import datetime
year = int(datetime.date.today().year) + 1

db.define_table('jasen', Field('Nimi', type='string', required=True,),
	Field('Osoite', type='string'),
	Field('LiittymisPVM', type='date'),
	Field('Syntymavuosi', type='integer', requires=IS_INT_IN_RANGE(1900,year)),
	format='%(Nimi)s'
	)
db.define_table('elokuva', Field('Nimi', type='string', required=True,unique=True),
	Field('Julkaisuvuosi', type='integer', requires=IS_INT_IN_RANGE(1900,year)),
	Field('Vuokrahinta', type='integer', requires=IS_INT_IN_RANGE(0,1e100)),
	Field('Arvio', type='integer', requires=IS_INT_IN_RANGE(0,10)),
	Field('Lajityyppi', type='string', requires=IS_IN_SET(['Komedia','Toiminta','Kauhu','Draama'])),
	format='%(Nimi)s'
	)
	
db.define_table('vuokraus', Field('vuokraaja', 'reference jasen', required=True, requires=IS_IN_DB(db,'jasen.id','%(Nimi)s')),
	Field('elokuva', 'reference elokuva', required=True, requires=IS_IN_DB(db,'elokuva.id','%(Nimi)s')),
	Field('VuokrausPVM', type='date', required=True, requires=IS_DATE_IN_RANGE(format=T('%Y-%m-%d'), minimum=datetime.date(2016,1,1), maximum=datetime.date(2099,12,31), error_message='Täytyy olla YYYY-MM-DD ja myöhemmin kuin 1.1.2016')),
	Field('PalautusPVM'),
	Field('Maksettu', type='integer', required=True, requires=IS_INT_IN_RANGE(0,1e100))
	)